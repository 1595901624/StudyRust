/// 食物
pub struct Food {
    pub position: [usize; 2],
    pub eat: bool,
}