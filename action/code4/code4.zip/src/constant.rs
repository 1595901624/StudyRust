pub const WIDTH: usize = 80;
pub const HEIGHT: usize = 15;

// 地图/墙
pub type Map = [[&'static str; WIDTH]; HEIGHT];
